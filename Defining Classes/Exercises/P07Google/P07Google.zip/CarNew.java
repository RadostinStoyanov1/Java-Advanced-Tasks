package P14DefiningClasses_Exercise.P07Google;

public class CarNew {
    private String carModel;
    private int carSpeed;

    public CarNew(String carModel, int carSpeed) {
        this.carModel = carModel;
        this.carSpeed = carSpeed;
    }

    public String getCarModel() {
        return carModel;
    }

    public int getCarSpeed() {
        return carSpeed;
    }
}
