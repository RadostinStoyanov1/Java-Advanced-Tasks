package P13DefiningClasses;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int countCars = Integer.parseInt(scanner.nextLine());

        for (int count = 0; count < countCars; count++) {
            String data = scanner.nextLine();
            String brand = data.split("\\s+")[0];
            String model = data.split("\\s+")[1];
            int hP = Integer.parseInt(data.split("\\s+")[2]);

            Car car = new Car();
            car.setBrand(brand);
            car.setModel(model);
            car.setHorsePower(hP);

            System.out.println(car.toString());
        }

    }
}
