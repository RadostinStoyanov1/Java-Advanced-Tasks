//package P17Generics.P01JarOfT;

public class Main {
    public static void main(String[] args) {

        /*Jar<String> stringJar = new Jar<>();
        stringJar.add("Ivan");
        stringJar.add("Petar");
        String removedElement = stringJar.remove();
        System.out.println(removedElement);

        Jar<Integer> integerJar = new Jar<>();
        integerJar.add(1);
        integerJar.add(2);
        integerJar.add(3);
        int removedNum = integerJar.remove();
        System.out.println(removedNum);*/
    }
}
